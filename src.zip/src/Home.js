import React, { useState } from "react";
import { P1 } from "./P1";
import { P2 } from "./P2";

export default class Home extends React.Component {
    constructor(props){
        super(props);
        this.state={
            text:"initially loaded.",
            style:{}
        }
    }

    componentDidMount(){
        setTimeout(() => {
            this.setState({style:{color:"red",backgroundColor:'rgb(57, 250, 32)'} ,text:"Content Changed after 5000ms."});
        }, 5000);
    }

    render(){
        return(
            <div className="container pb-2 text-white" style={{border:'1px solid red'}}>
                Home Component
                <br/>
                <h1>App Online!!!! <span style={this.state.style}>{this.state.text}</span></h1>
                <P1></P1>
            </div>
        );
    }
}