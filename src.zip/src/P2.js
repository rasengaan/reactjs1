import React, { useState } from "react";
import propTypes from "prop-types";
import Home from './Home';

export const P2 = (props) => {
    console.log(props);
    return(
        <div style={{border:'1px solid yellow'}}>
            <h2>
                P2 Receiving Props!<br/>
                Prop: {props.test.key}
            </h2>
        </div>
    )
}

    P2.prototype={
        test: propTypes.exact({
            key:propTypes.string
        })
    }