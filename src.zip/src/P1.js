import React, { useState, useEffect } from "react";
import { P2 } from "./P2";

export const P1 =  (props) => {
    const [count, setcount] = useState(0);
    const [test, settest] = useState(0);

    useEffect(() => {
        console.log("Updating Count variables")
    },[count, test])

    return(
        <div className=" p-2" style={{border:'1px solid green'}}>
            P1 Component
            <h2 onClick={()=>{settest(test+1);}} onDoubleClick={()=>{settest(test+5)}}>P1 running!!  State: ClickCount test: {test}</h2>
            <h2 onClick={()=>{setcount(count+1);}} onDoubleClick={()=>{setcount(count+5)}}>P1 running!!  State: ClickCount count: {count}</h2>
            <P2 test={{key:"tyhgfhghgfhhf"}}></P2>
        </div>
    );
}