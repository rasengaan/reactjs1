import React from "react";

export const LightMode = React.createContext("light");